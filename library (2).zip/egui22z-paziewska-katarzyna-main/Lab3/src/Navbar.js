import useFetch from "./useFetch";
import { useHistory } from "react-router-dom";
import BookList from "./BookList";
const Navbar = () => {
    const username = JSON.parse(localStorage.getItem('name'))
    const {data: books, isPending, Error} = useFetch("http://localhost:8000/books");
    const {data: users, isPending2, Error2} = useFetch("http://localhost:8001/users");
    const history = useHistory();
    const logout =async =>{
        localStorage.setItem('name', JSON.stringify(null));
        console.log('logged');
        history.push('/home');
    }

    const deleteAcc= async => {
        const username = JSON.parse(localStorage.getItem('name'));     
        const check = books.find(books => books.leased == username);
        console.log(check);

        if (check == null){
            const user = users.find(users => users.username == username);
            const id = user.id;
            fetch('http://localhost:8001/users/'+id, {
             method: 'DELETE'})
            logout();   
            
        }
        else {
            

            history.push('/useraccount');
        }


    }

    return (
      <nav className="navbar">
        <h1>The Library</h1>
        <div className="links">
            {username == null &&
            <a href="/login">Login</a>
            
            }
            {username == null &&
            <a href="/register" style={{ 
              color: 'white', 
              backgroundColor: '#f1356d',
              borderRadius: '8px' 
            }}>Register</a>
        }
          
          {username != null &&
                    <a href = '/home' onClick={() => logout()}>Logout</a>
                }
            {username != null && username != 'librarian' &&
                    <button onClick={() => deleteAcc()}>Delete account</button>
                }
        </div>
      </nav>
    );
  }
   
  export default Navbar;