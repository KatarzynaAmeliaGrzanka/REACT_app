import { useEffect, useState } from "react";
import BookList from "./BookList";
import useFetch from "./useFetch";


const Librarianccount = () => {
    const {data: books, isPending, Error} = useFetch("http://localhost:8000/books");
   // const username = username;
   //const username = localStorage.getItem('name', JSON.stringify());
   const username = JSON.parse(localStorage.getItem('name'))
    
    return (
      <div className="librarianaccount">
        <h2>Hello {username}!</h2>
        <h2></h2>
            
            
            {books && <BookList books={books} title = "Books in library" />}

      </div>
    );
  }
   
  export default Librarianccount;