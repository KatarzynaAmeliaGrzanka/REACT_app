import Navbar from './Navbar';
import Home from './Home';
import Register from './Register';
import Login from './Login';
import Useraccount from './Useraccount';
import Librarianaccount from './Librarianaccount';
import axios from 'axios';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';




function App() {
  return (
    <Router>
            <div className="App">
        <Navbar />
        <div className="content">
          <Switch>
            <Route exact path ="/">
              <Home />
            </Route>
            <Route exact path ="/home">
              <Home />
            </Route>
            <Route exact path ="/register">
              <Register />
            </Route>
            <Route path ="/login">
              <Login />
            </Route>
            <Route path ="/useraccount/">
              <Useraccount />
            </Route>
            <Route path ="/librarianaccount/">
              <Librarianaccount />
            </Route>
          </Switch>
        </div>
      </div>
    </Router>

  );
}

export default App;