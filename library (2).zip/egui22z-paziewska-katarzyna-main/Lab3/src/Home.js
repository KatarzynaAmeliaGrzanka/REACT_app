import { useEffect, useState } from "react";
import BookList from "./BookList";
import useFetch from "./useFetch";


const Home = () => {
  
    
    
    return (
      <div>
        <h2>Welcome in the library!!!   </h2>
        <a>Are you a user? Login!</a>
        <br></br>
        <a>You want to be a user? Register!</a>

      </div>
    );
  }
   
  export default Home;

  