
import { useHistory } from "react-router-dom";

const BookList = (props) => {
    const books = props.books;
    const title = props.title;
    
    const history = useHistory();
    console.log(props,books);
    const username = JSON.parse(localStorage.getItem('name'))
    
   
const checkIfExpired = async(book) =>{
    const current = new Date();
    const today= `${current.getDate()}/${current.getMonth()+1}/${current.getFullYear()}`;
    if (book.reserved - today < 0 ){
        removeRes(book);    
    }
}
    const removeRes = async (book) =>{
        book.user = "";
        book.reserved = "";
        const id = book.id;
        fetch('http://localhost:8000/books/'+id, {
             method: 'PUT',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(book)
    }).then(() => {
      console.log('reserved');
      history.go(0);
    })
    }

    const reserve = async (book) =>{
        book.user = username;
        const current = new Date();
        book.reserved = `${current.getDate()}/${current.getMonth()+1}/${current.getFullYear()}`;
        const id = book.id;
        fetch('http://localhost:8000/books/'+id, {
             method: 'PUT',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(book)
    }).then(() => {
      console.log('reserved');
      history.go(0);
    })
    }

    const rent = async (book) =>{
        book.leased = book.user;
        const id = book.id;
        fetch('http://localhost:8000/books/'+id, {
             method: 'PUT',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(book)
    }).then(() => {
      console.log('rented');
      history.go(0);
    })
    }
    const returnBook = async (book) =>{
        book.leased = "";
        book.reserved = "";
        book.user = "";
        const id = book.id;
        fetch('http://localhost:8000/books/'+id, {
             method: 'PUT',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(book)
    }).then(() => {
      console.log('returned');
      history.go(0);
    })
    }



    return ( 
        <div className="book-list">
            <h2 style={{ 
            color: 'white', 
            backgroundColor: '#f1356d',
            borderRadius: '6px' 
                }}>{title}</h2>
            {books.map((book)=>
            <div className = "book-preview" key={book.user}>
                <h2 >Title: { book.title }</h2>
                <p>Author: {book.author}</p>
                <p>Publisher: {book.publisher}</p>
                <p>Date: {book.date}</p>
                
                {book.user == "" && username != 'librarian' &&
                    <button onClick={() => reserve(book)}>Reserve</button>
                }
                {book.user == username &&
                    <button onClick={() => removeRes(book)}>Remove reservation</button>
                }
                {username == 'librarian'&& book.user != "" &&book.leased == ""&&
                    <button onClick={() => rent(book)}>Rent</button>
                }
                {username == 'librarian'&& book.user != "" &&book.leased != ""&&
                    <button onClick={() => returnBook(book)}>Return</button>
                }
                
                


                
             </div>
            )}
        </div>
     );
}
 
export default BookList;