import { useState } from "react";
import { useHistory } from "react-router-dom";
import BookList from "./BookList";
import useFetch from "./useFetch";
import axios from "axios";


const Login = () => {
  const [username, setUsername] = useState('');
  const [pwd, setPwd] = useState('');
  const history = useHistory();
  const {data: users, isPending, Error} = useFetch("http://localhost:8001/users");
  const {data: books, isPending2, Error2} = useFetch("http://localhost:8000/books");

  const handleSubmit = async (e) => {
    e.preventDefault();
    //checkUserName(username, users);
    
    const user = users.find(users => users.username == username && users.pwd == pwd);
    const loggeduser = {username, pwd}
  // const user2 = users.find(users => users.pwd == pwd);
    if (user == null){
        
        history.push('/login');
    }
    else{
        if(username == 'librarian' && pwd == '123'){
            
            fetch("http://localhost:8003/user", {
                    method: 'PUT',
                })
                localStorage.setItem('name', JSON.stringify(user.username));
            history.push('/librarianaccount')
            window.location.reload(true);
        }
        else{
                fetch("http://localhost:8003/user", {
                    method: 'PUT',
                })
                //const {data: books, isPending, Error} = useFetch("http://localhost:8000/books");
              //  {books && <BookList books={books} title = "My reservations" />}
                //localStorage.setItem('name', JSON.stringify(username));
                localStorage.setItem('name', JSON.stringify(user.username));
                
                history.push('/useraccount');
                window.location.reload(true);
            }
        
        }  
}
  
  return (
    <div className="login">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <label>UserName:</label>
        <input 
          type="text" 
          required 
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          //onChange={(e) => checkUserName()}
        />
        <label>Password:</label>
        <input 
          type="password" 
          required 
          value={pwd}
          onChange={(e) => setPwd(e.target.value)}
        />
    
        
        <button>Login</button>
      </form>
    </div>
  );
}
 
export default Login;

