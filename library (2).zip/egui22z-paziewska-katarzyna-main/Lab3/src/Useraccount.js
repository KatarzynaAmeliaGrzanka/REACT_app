import { useEffect, useState } from "react";
import BookList from "./BookList";
import useFetch from "./useFetch";


const Useraccount = () => {
    const {data: books, isPending, Error} = useFetch("http://localhost:8000/books");
   // const username = username;
   //const username = localStorage.getItem('name', JSON.stringify());
   const username = JSON.parse(localStorage.getItem('name'))
   const [search, setSearch] = useState('');
    
    return (
      <div className="useraccount">
        <h2>Hello {username}!</h2>
        <h2></h2>
            
            
            {books && <BookList books={books} title = "Books in the library" />}
            <br></br>
            <br></br>
            <br></br>
            <label>Search for a title:</label>
        <input 
          type="text" 
          required 
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        {books && <BookList books={books.filter((book)=>book.title == search)} title = "Search results:" />}

      </div>
    );
  }
   
  export default Useraccount;