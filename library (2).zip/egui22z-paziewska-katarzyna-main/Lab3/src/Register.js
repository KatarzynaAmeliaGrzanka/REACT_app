import { useState } from "react";
import { useHistory } from "react-router-dom";
import useFetch from "./useFetch";

const Register = () => {
  const [username, setUsername] = useState('');
  const [pwd, setPwd] = useState('');
  const history = useHistory();
  const {data: users, isPending2, Error2} = useFetch("http://localhost:8001/users");

  const handleSubmit = (e) => {
    e.preventDefault();
   
    const user = { username, pwd };
    const check = users.find(users => users.username == username );

    if (check == null){
        fetch('http://localhost:8001/users/', {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(user)
          }).then(() => {
            console.log('new user added');
            history.push('/home');
          })
    }
    else{
        history.go(0);
    }

    
  }

  return (
    <div className="register">
      <h2>Register</h2>
      <form onSubmit={handleSubmit}>
        <label>UserName:</label>
        <input 
          type="text" 
          required 
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <label>Password:</label>
        <input 
          type="text" 
          required 
          value={pwd}
          onChange={(e) => setPwd(e.target.value)}
        />

        
        <button>Register</button>
      </form>
    </div>
  );
}
 
export default Register;

/*const Register = () => {

    return ( 
        <div className="register">
            <h2>Register</h2>
        </div>
     );
}
 
export default Register;*/