#include "register.h"
#include "ui_register.h"
#include "mainwindow.h"
#include "read_write_json.h"
#include <QMessageBox>

Register::Register(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Register)
{
    ui->setupUi(this);
}

Register::~Register()
{
    delete ui;
}

void Register::on_pushButton_clicked()
{
    string username = ui->lineEdit_username->text().toStdString();
    string password = ui->lineEdit_pwd->text().toStdString();
    vector<User> users = get_users();


    vector<User>::iterator tmp = users.begin();
    do{
        if(tmp->user == username){
            QMessageBox::warning(this, "Register", "Username already taken. Try other username.");
            break;
            }
     ++tmp;
    } while  (tmp != users.end());

    if(tmp == users.end())
        to_file(users, username, password);
    hide();
    ui2 = new MainWindow(this);
    ui2->show();
}


