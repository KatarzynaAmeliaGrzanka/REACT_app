#include <QCoreApplication>
#include <iostream>
#include "json.hpp"
#include <string>
#include <vector>
#include <fstream>
#include <json.hpp> // https://github.com/nlohmann/json/blob/develop/single_include/nlohmann/json.hpp

struct User {
  std::string user;
  std::string pwd;
};

void from_json(const nlohmann::json& j, User& p) {
    j.at("user").get_to(p.user);
    j.at("pwd").get_to(p.pwd);
}

void to_json(nlohmann::json& j, const User& p) {
    j = nlohmann::json{
      {"user", p.user}, {"pwd", p.pwd}
    };
}

int main(int argc, char *argv[]) {
    QCoreApplication a(argc, argv);

    std::cout << "hello" << std::endl;
    std::ifstream ifs("users.json");
    auto jf =  nlohmann::json::parse(ifs);
    ifs.close();
    auto users = jf.get<std::vector<User>>();
    std::cout << users[0].user << std::endl; // data read

    users[0].pwd = "secret";                 // data modification
    users.push_back(User{ "james", "567"});  // data insert
    users.erase(users.begin()+1);            // data removal

    std::ofstream ofs("output.json");
    ofs << std::setw(2) << nlohmann::json(users) << std::endl;
    ofs.close();
    //return a.exec();
}