#include "mainwindow.h"
#include "libr_acc.h"
#include "ui_mainwindow.h"
#include "read_write_json.h"
#include <QMessageBox>
#include <QSettings>
#include <QString>

using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_login_clicked()
{
    vector<User> users = get_users();
    string username = ui->lineEdit_username->text().toStdString();
    string password = ui->lineEdit_pwd->text().toStdString();
    QString userid;
    userid = userid.fromStdString(username);
    QSettings* settings = new QSettings(QSettings::IniFormat, QSettings::UserScope, "library3", "logins");
    settings->setValue("userID", userid);
    QString path_set = settings->fileName();
    get_path(path_set);

    if(username == "librarian"){
        if(password == "123"){
            hide();
            libr_acc = new class libr_acc(this);
            libr_acc->show();
        }
        else
            QMessageBox::warning(this, "Login", "Wrong password, try again.");
    }
    else{
        vector<struct User>::iterator iter = users.begin();
        int succesfull = 0;
        while(iter != users.end()){
            if(iter->user == username)
                if(iter->pwd == password){
                    QMessageBox::warning(this, "Login", "Login successfull");
                    succesfull = 1;
                    hide();
                    user_acc = new class user_acc(this);
                    user_acc->show();
                    break;
            }

            ++iter;
            }
        if(succesfull == 0){
            QMessageBox::warning(this, "Login", "Login unsuccessfull");
            this->close();
            MainWindow *back = new class MainWindow(this);
            back->show();
        }

    }
}


void MainWindow::on_pushButton_register_clicked()
{
    hide();
    registerr = new Register(this);
    registerr->show();
}

