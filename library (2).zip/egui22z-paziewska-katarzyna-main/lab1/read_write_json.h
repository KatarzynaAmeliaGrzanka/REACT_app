#ifndef READ_WRITE_JSON_H
#define READ_WRITE_JSON_H

#include <QCoreApplication>
#include <iostream>
#include "json.hpp"
#include <string>
#include <vector>
#include <fstream>
#include <json.hpp> // https://github.com/nlohmann/json/blob/develop/single_include/nlohmann/json.hpp

using namespace std;

struct User {
  std::string user;
  std::string pwd;
};

struct Books {
    string author;
    string title;
    int date;
    string publisher;
    string user;
    string reserved;
    string leased;
};

void from_json(const nlohmann::json& j, User& p);

void from_json(const nlohmann::json& j, Books& p);

void to_json(nlohmann::json& j, const User& p) ;

void to_file(vector<User> users, string username, string password);

void to_json(nlohmann::json& j, const Books& p);
void get_path(QString path_set);
string get_userID();
vector<User> get_users();
vector<Books> get_books();
void remove_reservation(int id);
void update_reservations();

#endif // READ_WRITE_JSON_H



