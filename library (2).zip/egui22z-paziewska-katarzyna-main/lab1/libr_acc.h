#ifndef LIBR_ACC_H
#define LIBR_ACC_H

#include "qmainwindow.h"
#include "qstandarditemmodel.h"
#include <QDialog>

namespace Ui {
class libr_acc;
}

class libr_acc : public QDialog
{
    Q_OBJECT

public:
    explicit libr_acc(QWidget *parent = nullptr);
    ~libr_acc();

private:
    Ui::libr_acc *ui;
    QMainWindow *ui2;
    QStandardItemModel *model;

private slots:
    void table_books();
    void on_pushButton_rent_clicked();
    void on_pushButton_available_clicked();
    void on_pushButton_logout_clicked();
};


#endif // LIBR_ACC_H
