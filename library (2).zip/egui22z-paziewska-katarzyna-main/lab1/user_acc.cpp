#include "user_acc.h"
#include "mainwindow.h"
#include "read_write_json.h"
#include "ui_user_acc.h"

#include <QAbstractItemView>
#include <QDialog>
#include <QSettings>
#include <QMessageBox>
#include <QDateTime>
#include <QSettings>

user_acc::user_acc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::user_acc)
{
    ui->setupUi(this);
    table_books();
}

user_acc::~user_acc()
{
    delete ui;

}

void user_acc::table_books(){
    vector<Books> books;
    model = new QStandardItemModel(get_books().size(), 5, this);

    QStringList list;
    QModelIndex index;
    update_reservations();
    books = get_books();

    list<<"Title"<<"Author"<<"Publisher"<<"Date"<<"Status"<<"You reserved";
    model->setHorizontalHeaderLabels(list);

    if (!books.empty()) {
            for(unsigned long long row = 0; row < books.size(); row++) {
                   index = model->index(row,0,QModelIndex());
                   model->setData(index, QString::fromStdString(books[row].title));
                   index = model->index(row,1,QModelIndex());
                   model->setData(index,QString::fromStdString(books[row].author));
                   index = model->index(row,2,QModelIndex());
                   model->setData(index,QString::fromStdString(books[row].publisher));
                   index = model->index(row,3,QModelIndex());
                   model->setData(index,int(books[row].date));
                   index = model->index(row,4,QModelIndex());


                       if (books[row].reserved != "")
                            model->setData(index,QString::fromStdString("reserved"));
                       else if (books[row].leased != "")
                            model->setData(index,QString::fromStdString("rented"));
                       else
                            model->setData(index,QString::fromStdString(""));
                       index = model->index(row,5,QModelIndex());

                       string userID = get_userID();
                       if (books[row].user == userID){
                            model->setData(index,QString::fromStdString("Yes"));
                       }
                       else
                            model->setData(index,QString::fromStdString("No"));

                       index = model->index(row,5,QModelIndex());
            }
        ui->tableView_books->setModel(model);
        ui->tableView_books->setEditTriggers(QAbstractItemView::NoEditTriggers);
     }
}


void user_acc::on_pushButton_reserve_clicked()
{
    int id = ui->tableView_books->currentIndex().row();
    vector<Books> books = get_books();
    vector<struct Books>::iterator iter = books.begin();
    int tmp = 0;
    while (iter != books.end()){
        if(tmp == id){
            if(iter->leased == "" && iter->reserved == ""){
                QDateTime date = QDateTime::currentDateTime();
                QString formattedTime = date.toString("yyyy-MM-dd");
                iter->reserved = formattedTime.toStdString();
                iter->user = get_userID();
                std::ofstream ofs("books.json");
                ofs<<std::setw(2)<<nlohmann::json(books)<<std::endl;
                ofs.close();
                QMessageBox::warning(this, "Reservation", "Reservation confirmed.");
            }
            else{
                QMessageBox::warning(this, "Reservation", "Sorry, you cannot reserve this book, try again later.");
            }
        }
        ++iter;
        ++tmp;
    }
    this->close();
    user_acc *back = new class user_acc(this);
    back->show();
}


void user_acc::on_pushButton_delete_clicked()
{
    remove_reservation(ui->tableView_books->currentIndex().row());
    QModelIndex index = model->index(ui->tableView_books->currentIndex().row(),5,QModelIndex());
    model->setData(index,QString::fromStdString("No"));
    this->close();
    user_acc *back = new class user_acc(this);
    back->show();

}


void user_acc::on_pushButton_clicked()
{
    vector<User> users = get_users();
    vector<Books> books = get_books();
    vector<struct Books>::iterator iter = books.begin();
    int tmp = 0;
    string current_user = get_userID();
    while (iter != books.end()){
        if (iter->leased == current_user)
            ++tmp;
        ++iter;
    }
    if(tmp != 0)
        QMessageBox::warning(this, "Delete", "You cannot delete you account due to borrowed books.");
    else{
        vector<struct User>::iterator iter2 = users.begin();
        while(iter2 != users.end()){
            if(iter2->user == current_user)
                break;
            else {
                ++iter2;
            }
        }
        users.erase(iter2);
        std::ofstream ofs("users.json");
        ofs << std::setw(2) << nlohmann::json(users) << std::endl;
        ofs.close();
        QMessageBox::warning(this, "Detele", "Account deleted.");

        hide();
        ui2 = new MainWindow(this);
        ui2->show();
    }
}


void user_acc::on_pushButton_logout_clicked()
{
    hide();
    ui2 = new MainWindow(this);
    ui2->show();
}

