#include <QCoreApplication>
#include <iostream>
#include "json.hpp"
#include "qdatetime.h"
#include <string>
#include <vector>
#include <fstream>
#include <json.hpp> // https://github.com/nlohmann/json/blob/develop/single_include/nlohmann/json.hpp
#include<read_write_json.h>
#include <QSettings>
using namespace std;

QString path;

void from_json(const nlohmann::json& j, User& p) {
    j.at("user").get_to(p.user);
    j.at("pwd").get_to(p.pwd);
}

void from_json(const nlohmann::json& j, Books& p) {
   // j.at("id").get_to(p.id);
    j.at("author").get_to(p.author);
    j.at("title").get_to(p.title);
    j.at("publisher").get_to(p.publisher);
    j.at("date").get_to(p.date);
    j.at("user").get_to(p.user);
    j.at("reserved").get_to(p.reserved);
    j.at("leased").get_to(p.leased);
}

void to_json(nlohmann::json& j, const User& p) {
    j = nlohmann::json{
      {"user", p.user}, {"pwd", p.pwd}
    };
}

void to_json(nlohmann::json& j, const Books& p) {
    j = nlohmann::json{
      {"author", p.author}, {"title", p.title}, {"publisher", p.publisher}, {"date", p.date}, {"user", p.user}, {"reserved", p.reserved}, {"leased", p.leased}
    };
}

void to_file(vector<User> users, string username, string password) {
    users.push_back(User{username, password});  // data insert
    std::ofstream ofs("users.json");
    ofs << std::setw(2) << nlohmann::json(users) << std::endl;
    ofs.close();
}


vector<User> get_users() {
    ifstream ifs("users.json");
    auto jf =  nlohmann::json::parse(ifs);
    ifs.close();
    vector<User> users = jf.get<std::vector<User>>();
    return users;
}

vector<Books> get_books() {
    ifstream ifs("books.json");
    auto jf =  nlohmann::json::parse(ifs);
    ifs.close();
    vector<Books> books = jf.get<std::vector<Books>>();
    return books;
}

void get_path(QString path_set) {
    path = path_set;
}

string get_userID()
{
    QSettings settings(path, QSettings::IniFormat);
    return (settings.value("userID").toString()).toStdString();
}

void remove_reservation(int id) {
    vector<Books> books = get_books();
    int tmp = 0;
    vector<struct Books>::iterator iter = books.begin();
    while(iter != books.end()) {
        if(tmp == id && iter->user == get_userID()) {
           iter->user = "";
           iter->reserved = "";
        }
        ++tmp;
        ++iter;
    }
    std::ofstream ofs("books.json");
    ofs << std::setw(2) << nlohmann::json(books) << std::endl;
    ofs.close();
}



void update_reservations(){
    QDateTime date_now = QDateTime::currentDateTime();
    date_now = date_now.addDays(-1);
    vector<Books> books = get_books();
    vector<struct Books>::iterator iter = books.begin();
    while(iter != books.end()){
        if(iter->reserved == date_now.toString("yyyy-MM-dd").toStdString()){
            iter->reserved = "";
            iter->user = "";
            std::ofstream ofs("books.json");
            ofs << std::setw(2) << nlohmann::json(books) << std::endl;
            ofs.close();
        }
        ++iter;
    }
}
