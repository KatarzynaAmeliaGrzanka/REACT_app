#ifndef USER_ACC_H
#define USER_ACC_H
#include "qmainwindow.h"
#include <QStandardItemModel>
#include <QDialog>

namespace Ui {
class user_acc;
}

class user_acc : public QDialog
{
    Q_OBJECT

public:
    explicit user_acc(QWidget *parent = nullptr);
    ~user_acc();

private:
    Ui::user_acc *ui;
    QStandardItemModel *model;
    QMainWindow *ui2;

private slots:
    void table_books();
    void on_pushButton_reserve_clicked();
    void on_pushButton_delete_clicked();
    void on_pushButton_clicked();
    void on_pushButton_logout_clicked();
};



#endif // USER_ACC_H
