#include "libr_acc.h"
#include "qstandarditemmodel.h"
#include "read_write_json.h"
#include "ui_libr_acc.h"
#include "mainwindow.h"
#include <QMessageBox>

libr_acc::libr_acc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::libr_acc)
{
    ui->setupUi(this);
    table_books();
}

libr_acc::~libr_acc()
{
    delete ui;
}

void libr_acc::table_books(){
    vector<Books> books;
    model = new QStandardItemModel(get_books().size(), 4, this);

    QStringList list;
    QModelIndex index;

    books = get_books();
    update_reservations();
    list<<"Title"<<"Author"<<"Publisher"<<"Date"<<"Status";
    model->setHorizontalHeaderLabels(list);

    if (!books.empty()) {
            for(unsigned long long row = 0; row < books.size(); row++) {
                   index = model->index(row,0,QModelIndex());
                   model->setData(index, QString::fromStdString(books[row].title));
                   index = model->index(row,1,QModelIndex());
                   model->setData(index,QString::fromStdString(books[row].author));
                   index = model->index(row,2,QModelIndex());
                   model->setData(index,QString::fromStdString(books[row].publisher));
                   index = model->index(row,3,QModelIndex());
                   model->setData(index,int(books[row].date));
                   index = model->index(row,4,QModelIndex());


                       if (books[row].reserved != "")
                            model->setData(index,QString::fromStdString("reserved"));
                       else if (books[row].leased != "")
                            model->setData(index,QString::fromStdString("rented"));

                       else
                            model->setData(index,QString::fromStdString(""));
                       index = model->index(row,5,QModelIndex());


            }
        ui->tableView_books->setModel(model);
        ui->tableView_books->setEditTriggers(QAbstractItemView::NoEditTriggers);
     }
}



void libr_acc::on_pushButton_rent_clicked()
{
    int id = model->index(ui->tableView_books->currentIndex().row(),5).data().toInt();
    vector<Books> books = get_books();
    vector<struct Books>::iterator iter = books.begin();
    int tmp = 0;

    while (iter != books.end()){
        if(tmp == id){
            if (iter->reserved == "")
                QMessageBox::warning(this, "Reservation", "Cannot rent this book.");
            else{
                iter->leased = iter->user;
                iter->reserved = "";
                std::ofstream ofs("books.json");
                ofs<<std::setw(2)<<nlohmann::json(books)<<std::endl;
                ofs.close();
                QMessageBox::warning(this, "Reservation", "Book rented succesfully.");
                break;
            }
        }
        ++iter;
        ++tmp;
    }
    this->close();
    libr_acc *back = new class libr_acc(this);
    back->show();
}


void libr_acc::on_pushButton_available_clicked()
{
    int id = model->index(ui->tableView_books->currentIndex().row(),5).data().toInt();
    vector<Books> books = get_books();
    vector<struct Books>::iterator iter = books.begin();
    int tmp = 0;

    while (iter != books.end()){
        if(tmp == id){
            if (iter->leased == "")
                QMessageBox::warning(this, "Make available", "Book not rented.");
            else{
                iter->leased = "";
                iter->reserved = "";
                iter->user = "";
                std::ofstream ofs("books.json");
                ofs<<std::setw(2)<<nlohmann::json(books)<<std::endl;
                ofs.close();
                QMessageBox::warning(this, "Make available", "Book available.");
                break;
            }
        }
        ++iter;
        ++tmp;
    }
    this->close();
    libr_acc *back = new class libr_acc(this);
    back->show();
}


void libr_acc::on_pushButton_logout_clicked()
{
    hide();
    ui2 = new MainWindow(this);
    ui2->show();
}

